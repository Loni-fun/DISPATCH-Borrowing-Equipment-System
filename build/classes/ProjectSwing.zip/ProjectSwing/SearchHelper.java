/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ProjectSwing;

import java.util.ArrayList;
import java.util.function.Function;

public class SearchHelper {
    // DSA
    // your binary search for int ids, same method, only the if/else is tidied
    public static int binarySearch(int[] arr, int low, int high, int target) {
        if (low > high) {
            return -1;
        }
        int mid = low + (high - low) / 2;
        if (arr[mid] == target) {
            return mid;
        } else if (arr[mid] > target) {
            return binarySearch(arr, low, mid - 1, target);
        } else {
            return binarySearch(arr, mid + 1, high, target);
        }
    }

    // same idea for text: returns the index of the FIRST key that is equal to or bigger than the target
    // keys must be sorted
    public static int firstMatch(String[] keys, int low, int high, String target) {
        if (low > high) {
            return low;
        }
        int mid = low + (high - low) / 2;
        if (keys[mid].compareTo(target) >= 0) {
            return firstMatch(keys, low, mid - 1, target);    // the answer is mid or something before it
        } else {
            return firstMatch(keys, mid + 1, high, target);   // the answer is after mid
        }
    }

    // "EQ-12" -> 12, "REQ-3" -> 3, anything invalid -> -1
    public static int parseId(String text, String prefix){
        try{
            return Integer.parseInt(text.trim().toUpperCase().replace(prefix, ""));
        }catch(NumberFormatException e){
            return -1;
        }
    }

    // Used by every search JTextField.
    // For each field (name, id, serial...) it sorts the keys, binary searches the first key that starts
    // with the typed text, then walks forward while the keys still start with it.
    // Each field is a small function, e.g. s -> s.getLastName()
    @SafeVarargs
    public static <T> ArrayList<T> search(ArrayList<T> list, String keyword, Function<T, String>... fields){
        String word = keyword.trim().toLowerCase();
        if (word.isEmpty()) {
            return new ArrayList<>(list);
        }
        ArrayList<T> found = new ArrayList<>();
        for (Function<T, String> field : fields) {
            ArrayList<T> sorted = new ArrayList<>(list);
            sorted.sort((a, b) -> field.apply(a).toLowerCase().compareTo(field.apply(b).toLowerCase()));
            String[] keys = new String[sorted.size()];
            for (int i = 0; i < keys.length; i++) {
                keys[i] = field.apply(sorted.get(i)).toLowerCase();
            }
            int start = firstMatch(keys, 0, keys.length - 1, word);
            while (start < keys.length && keys[start].startsWith(word)) {
                if (!found.contains(sorted.get(start))) {
                    found.add(sorted.get(start));
                }
                start++;
            }
        }
        ArrayList<T> ordered = new ArrayList<>();   // keep the same order as the original list
        for (T item : list) {
            if (found.contains(item)) {
                ordered.add(item);
            }
        }
        return ordered;
    }
}
